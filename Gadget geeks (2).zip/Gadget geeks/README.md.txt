<<<<<<< HEAD
 GadgetGeeks by Liberty M

Project Overview
A professional, responsive website for GadgetGeeks by Liberty M - a premium tech accessories brand. This website showcases products, provides company information, and allows customers to make enquiries.

 Student Information
- Name: Tsholofelo Liberty Marokoane
- Student Number:ST10488592
- Group: Grp 1 DITM
- Subject: Web Development
- Date: 2026

 Website Pages
1. Home (index.html) - Hero section, featured products, categories
2. About (about.html) - Company story, mission, vision, team (2 members)
3. Products (products.html) - Product categories and listings
4. Enquiry (enquiry.html) - Product enquiry form
5. Contact (contact.html)- One location (Johannesburg , Braamfontein)

Technologies Used
- HTML5

How to View
1. Clone this repository
2. Open `index.html` in your web browser
3. Navigate through the pages using the menu

 GitHub Repository
This project is hosted on GitHub at:
[https://github.com/TsholofeloM220/GadgetGeeks-by-Liberty](https://github.com/TsholofeloM220/GadgetGeeks-by-Liberty)

 Changelog
Part 1 - HTML Structure (Complete)
- Created 5 HTML pages
- Added navigation menu
- Added images in assets/images/ folder
- Created enquiry form
- Added contact page with 1 location
- Added README.md

 Part 2 - CSS Styling (Coming Soon)
- Add responsive design
- Apply branding colors
- Style all pages

Part 3 - JavaScript (Coming Soon)
- Form validation
- Interactive features
- Shopping cart functionality

 
 References

Mozilla Developer Network, 2026. HTML: HyperText Markup Language. [online] Available at: https://developer.mozilla.org/en-US/docs/Web/HTML [Accessed 13 August 2026].

=======
 GadgetGeeks by Liberty M

Project Overview
A professional, responsive website for GadgetGeeks by Liberty M - a premium tech accessories brand. This website showcases products, provides company information, and allows customers to make enquiries.

 Student Information
- Name: Tsholofelo Liberty Marokoane
- Student Number:ST10488592
- Group: Grp 1 DITM
- Subject: Web Development
- Date: 2026

 Website Pages
1. Home (index.html) - Hero section, featured products, categories
2. About (about.html) - Company story, mission, vision, team (2 members)
3. Products (products.html) - Product categories and listings
4. Enquiry (enquiry.html) - Product enquiry form
5. Contact (contact.html)- One location (Johannesburg , Braamfontein)

Technologies Used
- HTML5

How to View
1. Clone this repository
2. Open `index.html` in your web browser
3. Navigate through the pages using the menu

 GitHub Repository
This project is hosted on GitHub at:
[https://github.com/TsholofeloM220/GadgetGeeks-by-Liberty](https://github.com/TsholofeloM220/GadgetGeeks-by-Liberty)

 Changelog
Part 1 - HTML Structure (Complete)
- Created 5 HTML pages
- Added navigation menu
- Added images in assets/images/ folder
- Created enquiry form
- Added contact page with 1 location
- Added README.md

 Part 2 - CSS Styling (Coming Soon)
- Add responsive design
- Apply branding colors
- Style all pages

Part 3 - JavaScript (Coming Soon)
- Form validation
- Interactive features
- Shopping cart functionality

 
 References

Mozilla Developer Network, 2026. HTML: HyperText Markup Language. [online] Available at: https://developer.mozilla.org/en-US/docs/Web/HTML [Accessed 13 August 2026].

>>>>>>> 38d3ab2764e067add5f8f066ffed38a3cb40841a
Smith, A., 2025. The growing demand for tech accessories in emerging markets. [online] Available at: https://www.techmarketinsights.com/emerging-markets-tech-accessories/ [Accessed 13 August 2026].